---
name: story-drafter
description: Turns messy meeting transcripts, email threads, chat snippets, workshop notes or half-written BRDs into Jira-ready user stories with Given/When/Then acceptance criteria. Flags contradictions, vague requirements and missing owners instead of guessing. Use whenever the user shares raw requirements material or asks for user stories, acceptance criteria, a backlog or a Jira import file.
---

# Story Drafter

Convert raw requirements material into a clean, traceable set of user stories, and surface every real problem in the material rather than hiding it. A reviewer should be able to trace each story back to what a source actually says.

## Workflow

1. **Label the sources.** Give each input a letter (Source A, B, C) and note its type (transcript, email, BRD, chat, notes). Use timestamps, section numbers or line references so every requirement can be traced back.
2. **Extract.** List every requirement, decision, constraint, dependency and assumption that is actually stated. Ignore small talk.
3. **Merge duplicates.** If the same requirement appears in several sources, write one story and list all sources.
4. **Run the issue checks** (below) before writing any story.
5. **Write the stories** in the format below.
6. **Assemble the output** in the order given under Output structure.
7. **Check before finishing.** Confirm that every cross-reference (S-, C-, V-, U-, G- IDs) points to the correct item, that the counts in the Summary match the lists, that no acceptance criterion goes beyond what a source says, and that every source citation points to the exact line that supports the requirement (see Citing sources).

## Rules that always apply

- Never invent numbers, thresholds, time limits, owners, dates, systems or priorities. Where something is not stated, write `[not stated]` and add it to the open questions.
- **Every acceptance criterion must trace to something a source says.** Do not write criteria for error messages, field validation, cut-offs, edge cases or failure handling that the sources never mention. Put them in the story's Notes as `[not stated]`, or, if you are reading something into the source, as `(assumed)`.
- Never silently resolve a conflict by picking a side or blending two requirements into one story.
- If you offer an idea the sources do not contain, label it **Suggestion** so it cannot be mistaken for a requirement.
- Do not make statements that vouch for your own output (for example "nothing here is invented" or "this is complete"). Let the traceability speak for itself.
- Do not flag things that are clear and consistent. Over-flagging makes the real issues harder to see.
- Use the role named in the sources (applicant, ops agent, compliance officer). If none is named, pick the most natural role and note it as an assumption only if the choice affects the story.
- Priorities are always labelled **Proposed** unless a source states one (use Must / Should / Could).

## Citing sources

Cite the exact reference of the line that supports each requirement:

- Transcripts: the timestamp of the speaker's line that states it (for example `A 01:55`), not the nearest earlier or later line.
- Emails: the message number and item number if numbered (for example `B msg 1, item 3`).
- Documents: the section or requirement ID (for example `C FR-5`, `C §5`).
- Chats and notes: the source letter plus the speaker or bullet (for example `E Priya`, `D bullet 2`).

If several lines support one requirement, list each. Before finishing, re-read each cited line and confirm it actually says what the story claims.

## Issue checks

**Contradictions.** Two sources, or two statements, that cannot both be true. Watch especially for absolute wording ("zero", "never", "always", "no exceptions") set against another source that requires an exception. Report each one under Conflicts with: requirement A and its source, requirement B and its source, why they are incompatible, and the decision needed (and who appears to own it, if the sources say). Mark the affected stories **Blocked** and keep them separate.

**Vague requirements.** Anything that cannot be tested, such as "fast", "easy to use", "user-friendly", "robust", "scalable", "secure", "intuitive", "etc." or "as needed". Do not turn these into stories. List them under Vague requirements with specific clarifying questions: what exactly is measured, what threshold counts as success, under what conditions or percentile, and how it will be verified. You may add a clearly labelled Suggestion if a related measurable target appears elsewhere in the sources.

**Missing owners and decisions.** Any action, decision or deliverable with no named owner, including phrases such as "somebody should", "we need to decide", "parked", "TBD" or "to be confirmed". List each under Unowned items, stating what is missing (owner, decision, deadline). Never assign an owner or pick an answer yourself. An item that already has a named owner is not unowned. Mention a missing date for a named owner only if a source says a deadline matters.

**Other gaps.** Blank sections, referenced documents that are not attached, undefined terms, and details a story needs but the sources never give. Only list a gap if it blocks a story or changes how a story would be built or tested. Do not list wording choices, minor role labels or trivia. Group related minor gaps into one line.

## Story format

Use this for every story:

**ID: Title**
As a [role], I want [goal], so that [benefit].
- Given [context], when [action], then [observable result]. (1 to 5 criteria, each testable and traceable to a source)

Priority (proposed): Must / Should / Could. Source: [exact references, see Citing sources]. Status: Ready, Needs confirmation or Blocked. Notes: dependencies, `[not stated]` details, assumptions.

Use IDs in the form `S-01` unless the user gives a Jira project key (then use `KEY-01`). Order stories in the natural flow of the user journey.

## Output structure

1. **Summary**: number of sources, stories (with a count by status), conflicts, vague requirements, unowned items and gaps.
2. **Decisions needed**: the 3 to 5 items a stakeholder must resolve first, in order of impact, each with the item ID and who appears to own it. Draw these from Conflicts, Unowned items and blocking gaps.
3. **User stories**: in the format above.
4. **Conflicts**
5. **Vague requirements (not converted to stories)**
6. **Unowned items and open decisions**
7. **Gaps and assumptions**
8. **Out of scope**: exactly as stated in the sources.

If a section is empty, write "None found" rather than leaving it out.

## Jira CSV

If the user mentions Jira or asks for "Jira-ready" stories, produce the CSV by default after the review sections, without asking. Otherwise, end by offering it.

**Columns (in this order):** `Summary`, `Issue Type`, `Description`, `Priority`, `Labels`.

- `Summary`: the story ID and title (for example `S-01: Enter personal details`).
- `Issue Type`: `Story`.
- `Description`: laid out on separate lines, using real line breaks (not the characters `\n`):

```
As a [role], I want [goal], so that [benefit].

Acceptance criteria:
1. Given ..., when ..., then ...
2. Given ..., when ..., then ...

Notes: [dependencies, [not stated] details, assumptions]
Status: [Ready / Needs confirmation / Blocked]
Source: [exact references]
```

- `Priority`: Must = High, Should = Medium, Could = Low.
- `Labels`: `needs-decision` for Blocked stories, `needs-confirmation` for Needs confirmation stories, empty for Ready stories.

Do not add a Source column or an ID or issue key column. The source is inside the Description, and Jira numbers the tickets itself.

**How to write the file.** Create a downloadable .csv file and present it. Build it with code, using Python's `csv` module (`csv.writer` with `quoting=csv.QUOTE_ALL`, `newline=""`, UTF-8 encoding), so that every field is quoted, double quotes inside text are escaped correctly, and the real line breaks inside Description stay inside their quoted field. Do not build the file by hand-typing commas and quotes.

**Verify before presenting.** Read the file back with the same module and confirm that the row count equals the number of stories, that every row has exactly 5 columns, that no Description contains the two-character sequence `\n`, and that the label counts match the Summary. If any check fails, fix the file and recheck. If file creation is not available, give the CSV in a code block with the same layout.

Do not include conflict, vague or unowned items as Jira rows unless the user asks. They belong in the review notes, not the backlog.
