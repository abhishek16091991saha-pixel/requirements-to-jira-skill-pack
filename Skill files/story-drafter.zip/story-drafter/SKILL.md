---
name: story-drafter
description: Turns messy meeting transcripts, email threads, chat snippets, workshop notes or half-written BRDs into Jira-ready user stories with Given/When/Then acceptance criteria. Flags contradictions, vague requirements and missing owners instead of guessing. Use whenever the user shares raw requirements material or asks for user stories, acceptance criteria, a backlog or a Jira import file.
---

# Story Drafter

Convert raw requirements material into a clean, traceable set of user stories, and surface every problem in the material rather than hiding it. A reviewer should be able to trust that nothing in the output was invented.

## Workflow

1. **Label the sources.** Give each input a letter (Source A, B, C) and note its type (transcript, email, BRD, chat, notes). Use timestamps, section numbers or line references so every requirement can be traced back.
2. **Extract.** List every requirement, decision, constraint, dependency and assumption that is actually stated. Ignore small talk.
3. **Merge duplicates.** If the same requirement appears in several sources, write one story and list all sources.
4. **Run the issue checks** (below) before writing any story.
5. **Write the stories** in the format below.
6. **Assemble the output** in the order given under Output structure.

## Rules that always apply

- Never invent numbers, thresholds, time limits, owners, dates, systems or priorities. Where something is not stated, write `[not stated]` and add it to the open questions.
- Never silently resolve a conflict by picking a side or blending two requirements into one story.
- If you offer an idea the sources do not contain, label it **Suggestion** so it cannot be mistaken for a requirement.
- Do not flag things that are clear and consistent. Over-flagging makes the real issues harder to see.
- Use the role named in the sources (applicant, ops agent, compliance officer). If none is named, pick the most natural role and note it as an assumption.
- Priorities are always labelled **Proposed** unless a source states one (use Must / Should / Could).

## Issue checks

**Contradictions.** Two sources, or two statements, that cannot both be true. Watch especially for absolute wording ("zero", "never", "always", "no exceptions") set against another source that requires an exception. Report each one under Conflicts with: requirement A and its source, requirement B and its source, why they are incompatible, and the decision needed (and who appears to own it, if the sources say). Mark the affected stories **Blocked** and keep them separate.

**Vague requirements.** Anything that cannot be tested, such as "fast", "easy to use", "user-friendly", "robust", "scalable", "secure", "intuitive", "etc." or "as needed". Do not turn these into stories. List them under Vague requirements with specific clarifying questions: what exactly is measured, what threshold counts as success, under what conditions or percentile, and how it will be verified. You may add a clearly labelled Suggestion if a related measurable target appears elsewhere in the sources.

**Missing owners and decisions.** Any action, decision or deliverable with no named owner or no date, including phrases such as "somebody should", "we need to decide", "parked", "TBD" or "to be confirmed". List each under Unowned items, stating what is missing (owner, deadline, decision). Never assign an owner or pick an answer yourself.

**Other gaps.** Blank sections, referenced documents that are not attached, undefined terms, and details a story needs but the sources never give. List these under Gaps and assumptions.

## Story format

Use this for every story:

**ID: Title**
As a [role], I want [goal], so that [benefit].
- Given [context], when [action], then [observable result]. (2 to 5 criteria, each testable and specific)

Priority (proposed): Must / Should / Could. Source: [source and reference]. Status: Ready, Needs confirmation or Blocked. Notes: dependencies, `[not stated]` details, assumptions.

Use IDs in the form `S-01` unless the user gives a Jira project key (then use `KEY-01`). Order stories in the natural flow of the user journey.

## Output structure

1. **Summary**: number of sources, stories, conflicts, vague requirements, unowned items and gaps.
2. **User stories**: in the format above.
3. **Conflicts**
4. **Vague requirements (not converted to stories)**
5. **Unowned items and open decisions**
6. **Gaps and assumptions**
7. **Out of scope**: exactly as stated in the sources.

If a section is empty, write "None found" rather than leaving it out.

After the output, offer to produce a Jira import CSV.

## Jira CSV

When asked, produce one row per story with these columns: `Summary`, `Issue Type` (Story), `Description` (the story sentence followed by the acceptance criteria as a labelled list and a Notes line), `Priority` (Must = High, Should = Medium, Could = Low), `Labels` (`needs-decision` for Blocked stories, `needs-confirmation` for Needs confirmation), `Source`. Leave any issue key or ID column out so Jira numbers the tickets itself. Quote every field and keep each row on one line (use `\n` inside Description for line breaks only if the user's Jira import supports it; otherwise use a semicolon-separated list). Provide the CSV as a downloadable file when file creation is available.

Do not include conflict, vague or unowned items as Jira rows unless the user asks. They belong in the review notes, not the backlog.
